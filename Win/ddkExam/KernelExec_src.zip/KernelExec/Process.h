#include <ntifs.h>

void RunProcess(LPSTR lpProcess);
