WinMerge/Plugins/readme.txt

Plugins holds the WinMerge runtime plugins, source code and binaries both.

These plugins allow transformations to files before diffing, or during
editing. See the manual for more information.

These filters are distributed in the MergePlugins
subdirectory beneath the WinMerge executables.
