This folder contains old changelog files.

Before WinMerge beta release 2.7.4 we did have several changelog files around
the source tree. Some folders had even two changelog files because of renamings
happening when we still were using CVS (usually changes.txt and readme.txt).

After WinMerge 2.7.4 beta we started using only one changelog file, which
content is meant for users. That file is:
/Docs/Users/ChangeLog.txt
There is no developer-changelog(s) anymore. That information can be get using
Subversion's log-commad.

As all these changelog files easily cause confusion, they were moved to one
one folder, which name is making it clear they are not current anymore.
