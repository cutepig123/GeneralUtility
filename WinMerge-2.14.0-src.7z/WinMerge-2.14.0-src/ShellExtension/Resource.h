//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShellExtension.rc
//
#define IDS_PROJNAME                    100
#define IDS_CONTEXT_MENU                101
#define IDR_WINMERGESHELL               102
#define IDS_CONTEXT_HELP                102
#define IDS_CONTEXT_HELP_MANYITEMS      103
#define IDS_COMPARE                     104
#define IDS_COMPARE_ELLIPSIS            105
#define IDS_COMPARE_TO                  106
#define IDS_HELP_SAVETHIS               107
#define IDS_HELP_COMPARESTORED          108
#define IDS_HELP_COMPARESAVED           109
#define IDS_RESELECT_FIRST              110
#define IDB_WINMERGE                    202

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
