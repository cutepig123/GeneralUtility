WinMerge\InnoSetup\readme.txt

InnoSetup holds the source for the WinMerge setup program, which uses the
InnoSetup setup engine.
